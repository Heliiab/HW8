// Helia Bayat    40223015
#include <stdio.h>
struct time
{
    int min;
    int sec;
};

struct runner
{
    char firstName[100];
    char lastName[100];
    long ID;
    struct time *record;
    struct time runningTime;
};

int main()
{
    int n, i;

    printf("Enter the number of players : ");
    scanf("%d", &n);
    struct runner A[n];
    struct runner temp;

    for (i = 0; i < n; i++)
    {
        printf("\nEnter first name : ");
        scanf("%s", A[i].firstName);

        printf("\nEnter last name : ");
        scanf("%s", A[i].lastName);

        printf("\nEnter ID : ");
        scanf("%ld", &A[i].ID);

        printf("\nEnter behtarin recorde sabt shode :\nmin : ");
        scanf("%d", &A[i].record->min);

        printf("\nsec : ");
        scanf("%d", &A[i].record->sec);

        printf("Enter record dar hamin mosabeghe :\nmin : ");
        scanf("%d", &A[i].runningTime.min);

        printf("\nsec : ");
        scanf("%d", &A[i].runningTime.sec);
    }

    float maxrunningTime = (A[0].runningTime.min * 60) + A[0].runningTime.sec; // min ro kardim sec.
    int maxindexrunningTime = 0;
    for (i = 1; i < n; i++)
    {
        if (maxrunningTime < (A[i].runningTime.min * 60) + A[i].runningTime.sec)
        {
            maxrunningTime = (A[i].runningTime.min * 60) + A[i].runningTime.sec;
            maxindexrunningTime = i;
        }
    }
    printf("nam va name khanevadegie barandeye mosabeghe :%s %s", A[maxindexrunningTime].firstName, A[maxindexrunningTime].lastName);

    if ((A[maxindexrunningTime].runningTime.min * 60) + A[maxindexrunningTime].runningTime.sec > ((A[maxindexrunningTime].record->min) * 60) + A[maxindexrunningTime].record->sec)
        printf("\ntoonest recordesho beshkane.");
    else
        printf("\natoonest recordesh beshkane.");

    float maxrecord = (A[0].record->min * 60) + A[0].record->sec; // min ro kardim sec.
    int maxindexrecord = 0;
    for (i = 1; i < n; i++)
    {
        if (maxrecord < (A[i].record->min * 60) + A[i].record->sec)
        {
            maxrecord = (A[i].record->min * 60) + A[i].record->sec;
            maxindexrecord = i;
        }
    }
    if (maxrecord < (A[maxindexrunningTime].runningTime.min * 60) + A[maxindexrunningTime].runningTime.sec)
        printf("toonest behtarin recorde kole sherkatkonandegano beshkanne");
    else
        printf("natoonest behtarin recorde kole sherkatkonandegano beshkanne");

    for (i = 0; i < n; i++)
    {
        if ((A[i].runningTime.min * 60 + A[i].runningTime.sec) > (A[i + 1].runningTime.min * 60 + A[i + 1].runningTime.sec))
        {
            temp = A[i];
            A[i] = A[i + 1];
            A[i + 1] = A[i];
        }
    }
    printf("firstName:  lastName:  ID:  record:  runningTime:\n");

    for (i = 0; i < n; i++)
    {
        printf("%s  %s  %ld  %d:%d  %d:%d", A[i].firstName, A[i].lastName, A[i].ID, A[i].record->min, A[i].record->sec, A[i].runningTime.min, A[i].runningTime.sec);
        printf("\n");
    }
    return 0;
}